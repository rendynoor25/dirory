﻿Dirory for SketchUp and Revit
=============================

SketchUp (2019 or newer)
  In SketchUp: Window > Extension Manager > Install Extension, choose
  SketchUp\DiroryLibrary-0.10.9.rbz, restart SketchUp, then
  Extensions > Dirory > Open Library Panel.

Revit (Windows)
  Close Revit, open the folder for your Revit ("Revit 2024" or
  "Revit 2025-2027") and double-click Install-Dirory.cmd, then start Revit and
  open the Dirory tab > Library.

Full guide: https://dirory.com/how-to-install
