﻿Dirory for SketchUp and Revit
=============================

SketchUp (2019 or newer)
  In SketchUp: Window > Extension Manager > Install Extension, choose
  SketchUp\DiroryLibrary-0.10.14.rbz, restart SketchUp, then
  Extensions > Dirory > Open Library Panel.

Revit 2024-2027 (Windows)
  Close Revit and double-click Revit\Dirory-Revit-Setup-0.1.24.exe. It finds
  each Revit 2024-2027 on this PC and installs for it. If Windows says
  "Windows protected your PC", click More info, then Run anyway. Then start
  Revit and open the Dirory tab > Library.

Full guide: https://dirory.com/how-to-install
