﻿Dirory for SketchUp and Revit
=============================

SketchUp (2019 or newer)
  In SketchUp: Window > Extension Manager > Install Extension, choose
  SketchUp\DiroryLibrary-0.10.1.rbz, restart SketchUp, then
  Extensions > Dirory > Open Library Panel.

Revit 2024 (Windows)
  Close Revit, open the Revit folder and double-click Install-Dirory.cmd,
  then start Revit and open the Dirory tab > Library.

Full guide: https://dirory.com/how-to-install
